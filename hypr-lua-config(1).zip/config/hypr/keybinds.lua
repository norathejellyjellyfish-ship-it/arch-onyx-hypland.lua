-- ==================================================
-- Hyprland Keybindings Configuration
-- File: keybinds.lua
-- Purpose: Define keyboard and mouse shortcuts for window management,
--          workspace switching, and system commands.
-- https://wiki.hypr.land/Configuring/Basics/Binds/
-- https://wiki.hypr.land/Configuring/Basics/Dispatchers/
--
-- NOTE ON CONFIDENCE: a handful of dispatcher argument shapes below
-- (resize_active's x/y fields, fullscreen's mode field, and the plain
-- exit dispatcher) are inferred from the documented hl.dsp.window.*
-- naming pattern and the official example config rather than confirmed
-- 1:1 from a wiki page for every field. If `hyprctl reload` complains,
-- open `hyprctl repl` and tab-complete `hl.dsp.window.` / `hl.dsp.` to
-- see the exact live signatures on your installed Hyprland version.
-- ==================================================

local vars = require("variables")
local mainMod = vars.mainMod

-- ------------------ Applications ----------------
hl.bind(mainMod .. " + RETURN", hl.dsp.exec_cmd(vars.terminal))                 -- Launch terminal
hl.bind(mainMod .. " + SPACE",  hl.dsp.exec_cmd(vars.menu))                     -- Launch application menu
hl.bind(mainMod .. " + B",      hl.dsp.exec_cmd(vars.browser))                  -- Launch browser
hl.bind(mainMod .. " + SHIFT + B", hl.dsp.exec_cmd(vars.browser .. " --private-window")) -- Launch private browser window

-- ------------------ Window Management ----------------
hl.bind(mainMod .. " + Q", hl.dsp.window.close())                    -- Close focused window
hl.bind(mainMod .. " + V", hl.dsp.window.float({ action = "toggle" })) -- Toggle floating for window
hl.bind(mainMod .. " + F", hl.dsp.window.fullscreen({ mode = 1 }))   -- Toggle fullscreen
hl.bind(mainMod .. " + P", hl.dsp.window.pseudo())                   -- Pseudotile toggle
hl.bind(mainMod .. " + X", hl.dsp.layout("togglesplit"))             -- Toggle split mode (dwindle only)
-- It's advised to prefer `uwsm stop` over hl.dsp.exit() where uwsm manages the session.
hl.bind(mainMod .. " + M", hl.dsp.exit())                            -- Exit Hyprland

-- ------------------ Focus Movement ----------------
hl.bind(mainMod .. " + H", hl.dsp.focus({ direction = "left" }))  -- Move focus left
hl.bind(mainMod .. " + L", hl.dsp.focus({ direction = "right" })) -- Move focus right
hl.bind(mainMod .. " + K", hl.dsp.focus({ direction = "up" }))    -- Move focus up
hl.bind(mainMod .. " + J", hl.dsp.focus({ direction = "down" }))  -- Move focus down

-- ------------------ Window Movement ----------------
hl.bind(mainMod .. " + SHIFT + H", hl.dsp.window.move({ direction = "left" }))  -- Move window left
hl.bind(mainMod .. " + SHIFT + L", hl.dsp.window.move({ direction = "right" })) -- Move window right
hl.bind(mainMod .. " + SHIFT + K", hl.dsp.window.move({ direction = "up" }))    -- Move window up
hl.bind(mainMod .. " + SHIFT + J", hl.dsp.window.move({ direction = "down" })) -- Move window down

-- ------------------ Workspace Switching & Move-to-Workspace ----------------
for i = 1, 5 do
  hl.bind(mainMod .. " + " .. i,         hl.dsp.focus({ workspace = i }))          -- Switch to workspace i
  hl.bind(mainMod .. " + SHIFT + " .. i, hl.dsp.window.move({ workspace = i }))    -- Move window to workspace i
end

-- ------------------ Resize Window ------------------
hl.bind(mainMod .. " + CTRL + H", hl.dsp.window.resize_active({ x = -20, y = 0 }))
hl.bind(mainMod .. " + CTRL + L", hl.dsp.window.resize_active({ x = 20, y = 0 }))
hl.bind(mainMod .. " + CTRL + K", hl.dsp.window.resize_active({ x = 0, y = -20 }))
hl.bind(mainMod .. " + CTRL + J", hl.dsp.window.resize_active({ x = 0, y = 20 }))

-- ------------------ Screenshots ----------------
hl.bind(mainMod .. " + S",         hl.dsp.exec_cmd("hyprshot -m region -o ~/screenshots"))
hl.bind(mainMod .. " + SHIFT + S", hl.dsp.exec_cmd("hyprshot -m window -o ~/screenshots"))

-- ------------------ System Commands ----------------
hl.bind(mainMod .. " + SHIFT + P", hl.dsp.exec_cmd("systemctl poweroff"))
hl.bind(mainMod .. " + SHIFT + R", hl.dsp.exec_cmd("systemctl reboot"))

-- ------------------ Special Workspaces ----------------
hl.bind(mainMod .. " + MINUS",         hl.dsp.workspace.toggle_special("magic"))
hl.bind(mainMod .. " + SHIFT + MINUS", hl.dsp.window.move({ workspace = "special:magic" }))

-- ------------------ Volume Control ----------------
-- Old `bindel` (repeating + locked, no release event) -> pass flags in the options table
hl.bind("XF86AudioRaiseVolume", hl.dsp.exec_cmd("wpctl set-volume @DEFAULT_AUDIO_SINK@ 5%+"), { locked = true, repeating = true })
hl.bind("XF86AudioLowerVolume", hl.dsp.exec_cmd("wpctl set-volume @DEFAULT_AUDIO_SINK@ 5%-"), { locked = true, repeating = true })

-- ------------------ Mouse Bindings ----------------
hl.bind(mainMod .. " + mouse:272", hl.dsp.window.drag(),   { mouse = true }) -- Move window with mouse button 272
hl.bind(mainMod .. " + mouse:273", hl.dsp.window.resize(), { mouse = true }) -- Resize window with mouse button 273
