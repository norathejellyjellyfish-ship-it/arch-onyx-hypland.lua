-- ==================================================
-- Hyprland Miscellaneous Configuration
-- File: misc.lua
-- Purpose: Miscellaneous settings for the Hyprland environment
-- ==================================================

hl.config({
  misc = {
    -- ------------------ Logo & Splash ----------------
    disable_hyprland_logo    = true, -- Disable Hyprland logo on startup
    disable_splash_rendering = true, -- Disable splash screen rendering

    -- ------------------ Wallpaper ----------------
    force_default_wallpaper = 0,           -- Do not force default wallpaper
    background_color        = "0x111111",  -- Default background color

    -- ------------------ Font ----------------
    font_family = "UbuntuMono Nerd Font", -- Default font for Hyprland UI
  },
})
