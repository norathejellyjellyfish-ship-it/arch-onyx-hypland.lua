-- ==================================================
-- Hyprland Main Configuration
-- File: hyprland.lua
-- Purpose: Main configuration file that requires all Hyprland modules
-- Since Hyprland 0.55, hyprlang (.conf) is deprecated in favor of Lua.
-- https://wiki.hypr.land/Configuring/Start/
-- ==================================================

-- ------------------ Variables ----------------
require("variables")      -- User-defined variables (colors, dpi, etc.)

-- ------------------ Environment ----------------
require("env")             -- Environment variables and startup commands

-- ------------------ Monitors & Input ----------------
require("monitors")        -- Monitor layouts and resolutions
require("input")           -- Input devices (keyboard, mouse) configuration
require("cursor")          -- Cursor settings

-- ------------------ Window Appearance ----------------
require("general")         -- General window settings (gaps, layout, borders)
require("decoration")      -- Window decoration (rounding, opacity, shadow, blur)
require("animations")      -- Window and workspace animations
require("misc")            -- Miscellaneous settings

-- ------------------ Keybindings & Rules ----------------
require("keybinds")        -- Keybindings for window management
require("rules")           -- Window-specific rules
