-- ==================================================
-- Hyprland General Configuration
-- File: general.lua
-- Purpose: Configure general window settings and layout
-- ==================================================

hl.config({
  general = {
    -- ------------------ Gaps ----------------
    gaps_in  = 8,  -- Inner gaps between windows
    gaps_out = 16, -- Outer gaps from screen edges

    -- ------------------ Border ----------------
    border_size = 2, -- Window border thickness
    col = {
      active_border   = "rgba(444444ff)", -- Color for focused window border
      inactive_border = "rgba(1a1a1aff)", -- Color for unfocused window border
    },

    -- ------------------ Layout ----------------
    layout        = "dwindle", -- Default layout (dwindle, master, etc.)
    allow_tearing = false,     -- Disable screen tearing
  },
})
