-- ==================================================
-- Hyprland Window Rules Configuration
-- File: rules.lua
-- Purpose: Define window-specific rules (opacity, behavior, etc.)
-- https://wiki.hypr.land/Configuring/Basics/Window-Rules/
-- ==================================================

-- ------------------ Browser Rules ----------------
-- Old:
-- windowrule {
--   name = browser-clear
--   match:class = ^(firefox)$
--   opaque = true
-- }
hl.window_rule({
  name  = "browser-clear",           -- Rule identifier
  match = { class = "^(firefox)$" }, -- Match windows with class 'firefox'
  opaque = true,                     -- Force window to be opaque (no transparency)
})
