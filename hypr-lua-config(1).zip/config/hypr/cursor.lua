-- ==================================================
-- Hyprland Cursor Configuration
-- File: cursor.lua
-- Purpose: Configure cursor behavior and appearance
-- ==================================================

hl.config({
  cursor = {
    -- ------------------ Hardware Cursor ----------------
    no_hardware_cursors = true, -- Use software cursor instead of hardware cursor

    -- ------------------ Inactivity ----------------
    inactive_timeout = 3, -- Time in seconds before cursor becomes inactive
  },
})
