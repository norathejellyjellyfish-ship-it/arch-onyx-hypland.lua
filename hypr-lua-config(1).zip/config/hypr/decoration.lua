-- ==================================================
-- Hyprland Decoration Configuration
-- File: decoration.lua
-- Purpose: Configure window appearance (rounding, opacity, shadows, blur)
-- ==================================================

hl.config({
  decoration = {
    -- ------------------ Window Geometry ----------------
    rounding = 16, -- Window corner radius (px)

    -- ------------------ Opacity ----------------
    active_opacity   = 0.95, -- Opacity for focused window
    inactive_opacity = 0.6,  -- Opacity for unfocused windows
    dim_special      = 0.0,  -- Dimming for special workspaces

    -- ------------------ Shadow ----------------
    shadow = {
      enabled      = true,           -- Enable window shadows
      range        = 20,             -- Shadow size/spread
      render_power = 3,              -- Shadow smoothness
      color        = "rgba(000000ee)", -- Shadow color (black with alpha)
    },

    -- ------------------ Blur ----------------
    blur = {
      enabled            = true,  -- Enable background blur
      size               = 2,     -- Blur kernel size
      passes             = 3,     -- Blur passes (quality/performance tradeoff)
      new_optimizations  = true,  -- Use optimized blur algorithm
      xray               = false, -- Disable blur-through for floating windows
      contrast           = 0.7,   -- Blur contrast adjustment
      brightness         = 0.5,   -- Blur brightness adjustment
      noise              = 0.3,   -- Grain/noise overlay
      vibrancy           = 80,    -- Color vibrancy boost (carried over as-is from
                                   -- the original .conf; note the upstream example
                                   -- config uses a 0-1 range, e.g. 0.1696 — verify
                                   -- against https://wiki.hypr.land/Configuring/Basics/Variables/
                                   -- if the blur looks off and lower this toward ~0.8)
      vibrancy_darkness  = 0.0,   -- Vibrancy reduction in dark areas
      special            = true,  -- Enable blur for special workspaces
    },
  },
})
