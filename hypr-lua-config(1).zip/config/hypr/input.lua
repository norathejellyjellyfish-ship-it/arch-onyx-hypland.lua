-- ==================================================
-- Hyprland Input Configuration
-- File: input.lua
-- Purpose: Configure keyboard layout, key options, and mouse behavior
-- ==================================================

hl.config({
  input = {
    -- ------------------ Keyboard Layout ----------------
    kb_layout  = "us,ua",                -- Primary and secondary keyboard layouts
    kb_options = "grp:alt_shift_toggle", -- Switch layouts with Alt+Shift

    -- ------------------ Mouse Settings ----------------
    follow_mouse = 1,  -- Focus window under mouse
    sensitivity  = 0,  -- Mouse sensitivity adjustment
  },
})
