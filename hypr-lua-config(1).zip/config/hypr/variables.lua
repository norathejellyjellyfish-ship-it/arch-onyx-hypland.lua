-- ==================================================
-- Hyprland Variables Configuration
-- File: variables.lua
-- Purpose: Define global variables for shortcuts and commands.
-- Lua has no shared globals across require()'d files by default, so we
-- return a table here. require("variables") is cached, so every file
-- that calls it gets the same table back.
-- ==================================================

local M = {}

-- ------------------ Default Applications ----------------
M.terminal = "alacritty"                  -- Default terminal emulator
M.menu     = "wofi --show drun"           -- Default application menu
M.browser  = "firefox"                    -- Default web browser

-- ------------------ Modifier Keys ----------------
M.mainMod  = "SUPER"                      -- Main modifier key (used in keybindings)

return M
