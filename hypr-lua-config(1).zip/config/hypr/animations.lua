-- ==================================================
-- Hyprland Animations Configuration
-- File: animations.lua
-- Purpose: Configure window and workspace animations
-- https://wiki.hypr.land/Configuring/Advanced-and-Cool/Animations/
-- ==================================================

-- ------------------ General Settings ----------------
hl.config({
  animations = {
    enabled = true, -- Enable/disable all animations
  },
})

-- ------------------ Bezier Curves ----------------
-- Old: bezier = myBezier, 0.05, 0.9, 0.1, 1.05
hl.curve("myBezier", {
  type   = "bezier",
  points = { { 0.05, 0.9 }, { 0.1, 1.05 } },
})

-- ------------------ Window Animations ----------------
-- Old: animation = windows, 1, 5, myBezier
hl.animation({ leaf = "windows", enabled = true, speed = 5, bezier = "myBezier" })

-- Old: animation = windowsOut, 1, 5, default, popin 80%
hl.animation({ leaf = "windowsOut", enabled = true, speed = 5, bezier = "default", style = "popin 80%" })

-- Old: animation = border, 1, 8, default
hl.animation({ leaf = "border", enabled = true, speed = 8, bezier = "default" })

-- Old: animation = fade, 1, 5, default
hl.animation({ leaf = "fade", enabled = true, speed = 5, bezier = "default" })

-- ------------------ Workspace Animations ----------------
-- Old: animation = workspaces, 1, 4, default
hl.animation({ leaf = "workspaces", enabled = true, speed = 4, bezier = "default" })
