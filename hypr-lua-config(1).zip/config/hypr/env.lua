-- ==================================================
-- Hyprland Environment Configuration
-- File: env.lua
-- Purpose: Set environment variables and startup commands for the Wayland session
-- ==================================================

-- ------------------ Environment Variables ----------------
-- Old: env = KEY,VALUE  ->  New: hl.env(KEY, VALUE)
hl.env("LIBVA_DRIVER_NAME", "nvidia")               -- Video acceleration driver
hl.env("XDG_SESSION_TYPE", "wayland")                -- Session type
hl.env("GBM_BACKEND", "nvidia-drm")                  -- Graphics backend for GBM
hl.env("__GLX_VENDOR_LIBRARY_NAME", "nvidia")        -- OpenGL vendor library

-- ------------------ Startup Commands ----------------
-- Old: exec-once = ...  ->  New: wrap in the hyprland.start event so it
-- only runs once at boot, not on every config reload.
-- https://wiki.hypr.land/Configuring/Basics/Autostart/
hl.on("hyprland.start", function()
  hl.exec_cmd("dbus-update-activation-environment --systemd WAYLAND_DISPLAY XDG_CURRENT_DESKTOP")
  hl.exec_cmd("hyprpaper")
  hl.exec_cmd("waybar")
end)
