-- ==================================================
-- Hyprland Monitors Configuration
-- File: monitors.lua
-- Purpose: Configure monitor layout, resolution, refresh rate, and scaling
-- https://wiki.hypr.land/Configuring/Basics/Monitors/
-- ==================================================

-- ------------------ Monitor Settings ----------------
-- Old: monitor = HDMI-A-1, 1920x1080@180, auto, 1
hl.monitor({
  output   = "HDMI-A-1", -- Monitor name
  mode     = "1920x1080@180", -- Resolution @ refresh rate
  position = "auto",     -- Transform: auto (normal orientation)
  scale    = 1,          -- Scale factor: 1 (no scaling)
})
